class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Page Kedua images
  static String imgLogo = '$imagePath/img_logo.png';

  static String imgLogo1 = '$imagePath/img_logo_1.png';

  static String imgLogo2 = '$imagePath/img_logo_2.png';

  static String imgLogo3 = '$imagePath/img_logo_3.png';

  static String imgFaiconsolidlOnprimarycontainer =
      '$imagePath/img_faiconsolidl_onprimarycontainer.svg';

  // Page Ketiga images
  static String imgLogo178x195 = '$imagePath/img_logo_178x195.png';

  // History (on progress) images
  static String imgCutbackground1 = '$imagePath/img_cutbackground1.png';

  static String imgFaiconsolidbolt = '$imagePath/img_faiconsolidbolt.svg';

  // Page QR (done) images
  static String imgFaiconsolidcamera = '$imagePath/img_faiconsolidcamera.svg';

  static String imgLabelcontainer = '$imagePath/img_labelcontainer.svg';

  // Pilihan Transfer images
  static String imgUsdcircle2 = '$imagePath/img_usdcircle2.png';

  static String imgMobilenotch1 = '$imagePath/img_mobilenotch1.png';

  // Common images
  static String imgWavebackground = '$imagePath/img_wavebackground.png';

  static String imgFaiconsolidl = '$imagePath/img_faiconsolidl.svg';

  static String imgFaiconsolidarrowleft =
      '$imagePath/img_faiconsolidarrowleft.svg';

  static String imgCaret = '$imagePath/img_caret.svg';

  static String imgLogo40x40 = '$imagePath/img_logo_40x40.png';

  static String imgSaly5 = '$imagePath/img_saly5.png';

  static String imgWavebackground812x374 =
      '$imagePath/img_wavebackground_812x374.png';

  static String imgLocation = '$imagePath/img_location.png';

  static String imgFaiconregular = '$imagePath/img_faiconregular.svg';

  static String imgQr = '$imagePath/img_qr.png';

  static String imgCoininhand1 = '$imagePath/img_coininhand1.png';

  static String img12 = '$imagePath/img_12.png';

  static String img21 = '$imagePath/img_21.png';

  static String imgGlobe = '$imagePath/img_globe.svg';

  static String imgFaiconbrandbitcoin = '$imagePath/img_faiconbrandbitcoin.svg';

  static String imgFaiconregularOnprimarycontainer =
      '$imagePath/img_faiconregular_onprimarycontainer.svg';

  static String imgFaiconbrandpaypal = '$imagePath/img_faiconbrandpaypal.svg';

  static String imgNavhome = '$imagePath/img_navhome.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
