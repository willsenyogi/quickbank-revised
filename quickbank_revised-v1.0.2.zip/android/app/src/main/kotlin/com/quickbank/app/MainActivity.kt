package com.quickbank.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
